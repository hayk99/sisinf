#!/bin/bash
#cp ficherosWeb.zip ~/Workspace/docker/practica1_material
#cd /tmp
#unzip ficherosWeb.zip
sudo rm -r "$HOME/sisinf"
sudo rm -r "$HOME/Workspace"

fichero="docker.zip"
dir="Workspace/sisinf/docker/tomcat"

# si no existe el directorio de tomcat, lo creamos
if [ ! -d "$HOME/$dir" ]
then
	mkdir -p "$HOME/$dir"
fi
#descomprimimos los ficheros correspondientes a la web
ubicacionFichero="$HOME/$dir"
sudo cp $fichero $ubicacionFichero
sudo unzip -q "$ubicacionFichero/$fichero" -d $ubicacionFichero 2>/dev/null

#comprobamos si existe el directorio sisinf, si no existe lo creamos
dirBBDD="sisinf/"
bbddFile="bbdd.zip"
if [ ! -d "$dirBBDD" ]
then
	mkdir -p "$HOME/$dirBBDD"
fi

#copiamos datos de la bbdd
ubicacionFileBBDD="$HOME/$dirBBDD"
sudo unzip -q "$bbddFile" -d "$ubicacionFileBBDD" 2>/dev/null
sudo docker stop sisinf-mariadb
#sudo docker start sisinf-mariadb
#creamos mariadb
mariadbScript="create_mariadb.sh"
sudo "./create_mariadb.sh" 	
#copiamos el script de lanzamiento del tomcat en el directorio del docker y ejecutams
#el script
tomcatScript="create_tomcat_v2.sh"
dirScript="$HOME/Workspace/sisinf/docker/"
sudo cp $tomcatScript $dirScript
cd $dirScript
pwd
#lanzamos el script
sudo docker stop sisinf-tomcat
sudo "./$tomcatScript"
